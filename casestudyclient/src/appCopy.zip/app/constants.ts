// export const BASEURL: string = 'http://localhost:8080/api';
// export const PDFURL = 'http://localhost:8080/PurchaseOrderPDF?poid=';
export const BASEURL = '/api';
export const PDFURL = '/PurchaseOrderPDF?poid=';
