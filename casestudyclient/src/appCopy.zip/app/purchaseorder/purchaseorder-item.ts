export interface PurchaseOrderItem {
  id: number;
  poid: number;
  productid: string;
  qty: number;
  price: number;
}
